import setuptools

setuptools.setup(
    name="ai42", 
    version="1.0.0",
    author="Ayoub Daoudia",
    author_email="ayoub.daoudia@um6p.ma",
    description="A ai42 package",
    python_requires=">=3.6",
)